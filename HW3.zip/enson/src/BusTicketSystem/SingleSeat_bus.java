package BusTicketSystem;
public class SingleSeat_bus extends Bus {
    private final int totalSeat;
    private final Seat door = new Seat();
    private int sold_seat=0;
    private static final int NUM_SEATS = 40; // to make our bus unchanged
    private final Seat[][] left;
    private final Seat[] right;
    public SingleSeat_bus(int bus_type,  String plate_number) {
        super(bus_type,plate_number);
        this.left = new Seat[2][14];
        this.right =new Seat[14];
        this.totalSeat = NUM_SEATS;
      //To initialize seat numbers
        for (int i = 0; i < right.length; i++) {
            if (i < 6) {
                right[i] = new Seat();
                right[i].setSeatNumber(3 * i + 1);
            } else if (i == 6) {
                right[i] = new Seat();
                right[i].setSeatNumber(17);
            } else if (i == 7) {
                right[i] = new Seat();
                right[i].setSeatNumber(18);
            } else if (i == 8) {
                right[i] = new Seat();
                right[i].setSeatNumber(21);
            } else if (i < 12) {
                right[i] = new Seat();
                right[i].setSeatNumber(3 * (i-1));
            } else if (i == 12) {
                right[i] = new Seat();
                right[i].setSeatNumber(35);
            } else {
                right[i] = new Seat();
                right[i].setSeatNumber(38);
            }
        }

        int num =2;
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 2; j++) {
                if(i<5){
                    left[j][i] = new Seat();
                    left[j][i].setSeatNumber(num);
                    num++;
                }
                if(i<7 && i>4){
                    left[j][i] = new Seat();
                    left[j][i].setSeatNumber((i - 5) * 3 + 19 + j);
                }
                else if(i == 7){
                    left[j][i]= door;
                }else if(i>7 && i <11){
                    left[j][i] = new Seat();
                    left[j][i].setSeatNumber(i * 3 + 1 + j);
                }
                else if(i>10){
                    left[j][i] = new Seat();
                    left[j][i].setSeatNumber(i * 3  + j);
                }
            }
            num++;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        // if the seat is sold ; put X to it
        // Print left side seats
        for (int i = 0; i < left[0].length; i++) {
            String seatStr;
            if(left[1][i]==door) {
                seatStr = "  ";
            } else {
                if(!left[1][i].isAvailable()) {
                    seatStr = "X ";
                } else {
                    seatStr = left[1][i].getSeatNumber() + " ";
                }
            }
            sb.append(seatStr);
        }
        sb.append("\n");

        for (int i = 0; i < left[0].length; i++) {
            String seatStr;
            if(left[0][i]==door) {
                seatStr = "  ";
            } else {
                if(!left[0][i].isAvailable()) {
                    seatStr = "X ";
                } else {
                    seatStr = left[0][i].getSeatNumber() + " ";
                }
            }
            sb.append(seatStr);
        }
        sb.append("\n\n");

        sb.append("D "); // It represents the driver seat
        for (Seat seat : right) {
            String seatStr;
            if (!seat.isAvailable()) {
                seatStr = "X ";
            } else {
                seatStr = seat.getSeatNumber() + " ";
            }
            sb.append(seatStr);
        }
        sb.append("\n");
        return sb.toString();
    }

    public void sellSeat(Passenger passenger, double rowPlacement) {

        if(passenger == null){
            throw new NullPointerException("Passenger cannot be null");
        }

        if (rowPlacement<0.0 || rowPlacement>1.0){
            throw new IllegalArgumentException("Not correct row");
        }

        if(getNumFreeSeats()==0){
            System.out.println("We are fully booked for this trip ");
            return;
        }

        int row = (int) (14 * rowPlacement);
        if(row == 14){row = 13;} // if row = 14 , it gives arrayoutofindexerror
        boolean flag = false;

        //in here first it puts pass to right then left
        // if left0 is full check its gender if gender same ok,if not put it to right
        while(flag == false){
            if(row == 14){row = 13;}
            if(right[row].isAvailable()){
                right[row].setPassenger(passenger);
                right[row].setTicket(new Ticket(right[row].getSeatNumber(), rowPlacement,passenger));
                right[row].getTicket().setPrice(150.0);
                System.out.println(right[row].getTicket().toString());
                System.out.println();
                sold_seat++;
                flag = true;
            }else{
                if (left[0][row].isAvailable()){
                    left[0][row].setPassenger(passenger);
                    left[0][row].setTicket(new Ticket(left[0][row].getSeatNumber(),rowPlacement,passenger));
                    left[0][row].getTicket().setPrice(130.0);
                    System.out.println(left[0][row].getTicket().toString());
                    System.out.println();
                    sold_seat++;
                    flag = true;
                }else if (left[1][row].isAvailable() && left[0][row].getPassenger().getGender().equals(passenger.getGender())  ) {
                    left[1][row].setPassenger(passenger);
                    left[1][row].setTicket(new Ticket(left[1][row].getSeatNumber(),rowPlacement,passenger));
                    left[1][row].getTicket().setPrice(130.0);
                    System.out.println(left[1][row].getTicket().toString());

                    sold_seat++;
                    flag = true;
                }
                else{
                    flag =  false;
                    row++;
                }
            }
        }
    }
    @Override
    public void sellSeat(Passenger[] passengers,double rowPlacement) {
        if(getNumFreeSeats() == 0){
            System.out.println("Sorry, we are fully booked. Please buy a ticket for another bus type or another trip");
            return;
        }

        if (rowPlacement<0.0 || rowPlacement>1.0){
            throw new IllegalArgumentException("Not correct row");
        }

        //first it puts 2 pass to left,if we have 1 pass it to the right
        //but if left is full, pass them to the right 1 by 1
        int temp=0;
        int row = (int) (14 * rowPlacement);
        if(row == 14){row = 13;}
        int row2 = row,row3=row2;
        int size = passengers.length;
        while(size>0){
            if(row == 14){row = 13;}
            if(size>1){
                if(temp<13){
                    if(left[0][row%14].isAvailable() && left[1][row%14].isAvailable()){
                        left[0][row%14].setPassenger(passengers[size-1]);
                        left[0][row%14].setTicket(new Ticket(left[0][row%14].getSeatNumber(),rowPlacement,passengers[size-1]));
                        left[0][row%14].getTicket().setPrice(120.0);
                        System.out.println(left[0][row%14].getTicket().toString());
                        left[1][row%14].setPassenger(passengers[size-2]);
                        left[1][row%14].setTicket(new Ticket(left[1][row%14].getSeatNumber(),rowPlacement,passengers[size-2]));
                        left[1][row%14].getTicket().setPrice(130.0);
                        System.out.println(left[1][row%14].getTicket().toString());
                        size-=2;
                    } else{
                        row++;
                    }
                    temp++;
                } else{
                    if(right[row3%14].isAvailable()){
                        right[row3%14].setPassenger(passengers[size-1]);
                        right[row3%14].setTicket(new Ticket(right[row2%14].getSeatNumber(),rowPlacement,passengers[size-1]));
                        right[row3%14].getTicket().setPrice(130.0);
                        System.out.println(right[row3%14].getTicket().toString());
                        size--;
                        row3=row2;
                    } else if(left[1][row3%14].isAvailable()&&left[0][row3%14].getPassenger().getGender() == passengers[size-1].getGender()){
                        left[1][row3%14].setPassenger(passengers[size-1]);
                        left[1][row3%14].setTicket(new Ticket(left[1][row3%14].getSeatNumber(),rowPlacement,passengers[size-1]));
                        left[1][row3%14].getTicket().setPrice(130.0);
                        System.out.println(left[1][row3%14].getTicket().toString());
                        row3=row2;
                        size--;
                    }
                    else{
                        row3++;
                    }
                }
            } else{
                row=row2;
                if(right[row%14].isAvailable()){
                    right[row%14].setPassenger(passengers[size-1]);
                    right[row%14].setTicket(new Ticket(right[row%14].getSeatNumber(),rowPlacement,passengers[size-1]));
                    right[row%14].getTicket().setPrice(130.0);
                    System.out.println(right[row%14].getTicket().toString());
                    size--;
                } else if (left[1][row%14].isAvailable() && left[0][row%14].getPassenger().getGender() == passengers[size-1].getGender()) {
                    left[1][row%14].setPassenger(passengers[size-1]);
                    left[1][row%14].setTicket(new Ticket(left[1][row%14].getSeatNumber(),rowPlacement,passengers[size-1]));
                    left[1][row%14].getTicket().setPrice(130.0);
                    System.out.println(left[1][row%14].getTicket().toString());
                    size--;
                } else{
                    row++;
                }
            }
        }
    }

    @Override
    public void makeSeatFree(int seatNumber) {
        for (Seat seat : right) {
            if (seat != null && seat.getSeatNumber() == seatNumber) {
               seat.release(seatNumber);
                return;
            }
            else if(seat == null){
                throw  new NullPointerException("This seat is not sold. We cannot apply your request");
            }
        }

        for (Seat[] seats : this.left) {
            for (Seat seat : seats) {
                if (seat != null && seat.getSeatNumber() == seatNumber) {
                    seat.release(seatNumber);
                    return;
                }
                else if(seat == null){
                    throw  new NullPointerException("This seat is not sold. We cannot apply your request");
                }
            }
        }
        sold_seat--;
    }
    public int getSold_seat() {return sold_seat;}
    @Override
    public int getNumFreeSeats() {return this.totalSeat - getSold_seat();}
}
