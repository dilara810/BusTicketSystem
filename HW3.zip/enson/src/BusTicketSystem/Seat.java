package BusTicketSystem;
public class Seat {
    private int seatNumber;
    private double rowPlacement;
    private Passenger passenger;
    private Ticket ticket;
    public Seat(int seatNumber, double rowPlacement) {
        this.seatNumber = seatNumber;
        this.rowPlacement = rowPlacement;
    }
    public Seat() {}
    public int getSeatNumber() {
        return seatNumber;
    }
    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }
    public double getRowPlacement() {
        return rowPlacement;
    }
    public boolean isAvailable() {
        return ticket == null;
    }
    public Passenger getPassenger() {
        return passenger;
    }
    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }
    public void release(int seatNumber) {
        if (this.seatNumber == seatNumber) {
            this.ticket = null;
        }
    }
    public Ticket getTicket() {
        return ticket;
    }
}
