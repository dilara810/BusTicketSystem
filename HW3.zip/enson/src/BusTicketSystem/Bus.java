package BusTicketSystem;
public abstract class Bus {
    protected int busType;
    protected String plateNumber;
    protected int numSeats;
    protected Seat[][] right2;
    public Bus(int busType, String plateNumber) {
        this.busType = busType;
        this.plateNumber = plateNumber;
        this.numSeats = numSeats;
    }
    public abstract void sellSeat(Passenger passenger,double rowPlacement);
    public abstract void sellSeat(Passenger[] passengers,double rowPlacement);
    public abstract void makeSeatFree(int seatNumber);
    public abstract int getNumFreeSeats();
    public  abstract String toString();
}
