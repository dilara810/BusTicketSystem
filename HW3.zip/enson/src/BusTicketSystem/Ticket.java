package BusTicketSystem;
public class Ticket {
    private int seatNumber;
    private double price;
    private Passenger passenger;

    public Ticket(int seatNumber, double price,Passenger passenger) {
        this.seatNumber = seatNumber;
        this.price = price;
        this.passenger = passenger;
    }
    public int getSeatNumber() {return seatNumber;}
    public void setPrice(double price) {this.price = price;}
    public double getPrice() {return this.price;}
    public Passenger getPassenger() {return passenger;}
    public void setPassenger(Passenger passenger) {this.passenger = passenger;}

    @Override
    public String toString() {
        return "Name: "+passenger.getName()+"\nSurname: "+passenger.getSurname()+"\nAge: "
                +passenger.getAge()+"\nSeat Number : "+getSeatNumber()
                +"\nPrice : "+ getPrice() +"TL";
    }
}
