package BusTicketSystem;
enum Gender{Female,Male};
public class Passenger {
    private String name;
    private String surname;
    private int age;
    private Gender gender;
    char gen;

    Passenger(){}
    public Passenger(String name, String surname, int age, char gen){
        this.age=age;
        this.name=name;
        this.surname=surname;
        this.gen =gen;
        setGender(gen);
    }

    //Getters and Setters
    public int getAge() {return age;}
    public String getName() {return name;}
    public String getSurname() {return surname;}
    public void setSurname(String surname) {this.surname = surname;}
    public void setAge(int age) {this.age = age;}
    public void setName(String name) {this.name = name;}

    public void setGender(char gender) {
        if(gender == 'm') {
            this.gender = Gender.Male;
        } else if(gender == 'f'){
            this.gender = Gender.Female;
        }
    }

    public Gender getGender() {return this.gender;}

    @Override
    public String toString(){
        return "Name : "+getName()+" Surname : "+getSurname()+" Gender : "+getGender();
    }

}
