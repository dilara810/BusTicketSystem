package BusTicketSystem;
public class DoubleSeat_bus extends Bus{
    private static final int NUM_SEATS = 44; // to initialize number of seats according to given example
    private final Seat door = new Seat(); // to determine door position
    private final int total_seat;
    private final Seat[][] left;
    private int sold_seat=0;
    private final Seat[][] right ;
    public DoubleSeat_bus(int bus_type, String plate_number) {
        super(bus_type, plate_number);
        this.left = new Seat[2][12];
        this.right = new Seat[2][12];
        this.total_seat = NUM_SEATS;

        int num =1;
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 2; j++) {
                if(i<5){
                    right[j][i] = new Seat();
                    right[j][i].setSeatNumber(num);
                    num++;
                }
                else if(i == 5){
                    right[0][i] = new Seat();
                    right[1][i] = new Seat();
                    right[0][i].setSeatNumber(21);
                    right[1][i].setSeatNumber(22);
                }
                else {
                    right[j][i] = new Seat();
                    right[j][i].setSeatNumber(4*i+1+j);
                }

            }
            num+=2;
        }

        //assigning left side number
        int num2=3;
        for (int i = 0; i < left[0].length; i++) {
            for (int j = 0; j < 2; j++) {
                if(i<5){
                    left[j][i] = new Seat();
                    left[j][i].setSeatNumber(num2);
                    num2++;
                }
                else if(i == 5){
                   left[j][i] = door;
                }
                else {
                    left[j][i] = new Seat();
                    left[j][i].setSeatNumber(4*i-1+j);
                }
            }
            num2+=2;
        }


   }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        // if the seat is sold ; put X to it
        // Print left side seats
        for (int i = 0; i < left[0].length; i++) {
            String seatStr;
            if(left[1][i]==door) {
                seatStr = "  ";
            } else {
                if(!left[1][i].isAvailable()) {
                    seatStr = "X ";
                } else {
                    seatStr = left[1][i].getSeatNumber() + " ";
                }
            }
            sb.append(seatStr);
        }
        sb.append("\n");

        for (int i = 0; i < left[0].length; i++) {
            String seatStr;
            if(left[0][i]==door) {
                seatStr = "  ";
            } else {
                if(!left[0][i].isAvailable()) {
                    seatStr = "X ";
                } else {
                    seatStr = left[0][i].getSeatNumber() + " ";
                }
            }
            sb.append(seatStr);
        }
        sb.append("\n\n");

        for (int i = 0; i < right[1].length; i++) {
            String seatStr;
                if(!right[1][i].isAvailable()) {
                    seatStr = "X ";
                } else {
                    seatStr = right[1][i].getSeatNumber() + " ";
                }
            sb.append(seatStr);
        }
        sb.append("\n");

        for (int i = 0; i < right[0].length; i++) {
            String seatStr;
                if(!right[0][i].isAvailable()) {
                    seatStr = "X ";
                } else {
                    seatStr = right[0][i].getSeatNumber() + " ";
                }

            sb.append(seatStr);
        }

        return sb.toString();
    }



    @Override
    public void sellSeat(Passenger passenger,double rowPlacement) {
        if(getNumFreeSeats() == 0){
            System.out.println("We are fully booked. Please choose another trip or another bus type");
        }

        if (rowPlacement<0.0 || rowPlacement>1.0){
            throw new IllegalArgumentException("Not correct row");
        }

        if (passenger == null){
            throw new NullPointerException("Passenger cannot be null");
        }

        int row = (int) (14 * rowPlacement);
        if(row == 14){row = 13;} // if row = 14 , it gives arrayoutofindexerror
        boolean flag = false;
        while(flag == false){
            if(row == 14){row = 13;}
            if(right[0][row].isAvailable()){
                right[0][row].setPassenger(passenger);
                right[0][row].setTicket(new Ticket(right[0][row].getSeatNumber(), rowPlacement,passenger));
                right[0][row].getTicket().setPrice(75.0);
                System.out.println(right[0][row].getTicket().toString());
                System.out.println();
                sold_seat++;
                flag = true;

            } else if (right[1][row].isAvailable() && right[0][row].getPassenger().getGender().equals(passenger.getGender())  ) {
                right[1][row].setPassenger(passenger);
                right[1][row].setTicket(new Ticket(right[1][row].getSeatNumber(),rowPlacement,passenger));
                right[1][row].getTicket().setPrice(75.0);
                System.out.println(right[1][row].getTicket().toString());
                System.out.println();
                sold_seat++;
                flag = true;

            } else{
                if (left[0][row].isAvailable()){
                    left[0][row].setPassenger(passenger);
                    left[0][row].setTicket(new Ticket(left[0][row].getSeatNumber(),rowPlacement,passenger));
                    left[0][row].getTicket().setPrice(75.0);
                    System.out.println(left[0][row].getTicket().toString());
                    System.out.println();
                    sold_seat++;
                    flag = true;
                }else if (left[1][row].isAvailable() && left[0][row].getPassenger().getGender().equals(passenger.getGender())  ) {
                    left[1][row].setPassenger(passenger);
                    left[1][row].setTicket(new Ticket(left[1][row].getSeatNumber(),rowPlacement,passenger));
                    left[1][row].getTicket().setPrice(75.0);
                    System.out.println(left[1][row].getTicket().toString());
                    System.out.println();
                    sold_seat++;
                    flag = true;
                }
                else{
                    flag =  false;
                    row++;
                }
            }
        }
    }

    @Override
    public void sellSeat(Passenger[] passengers, double rowPlacement) {
        if (getNumFreeSeats() == 0) {
            System.out.println("Sorry, we are fully booked. Please buy a ticket for another bus type or another trip");
            return;
        }

        if (rowPlacement < 0.0 || rowPlacement > 1.0) {
            throw new IllegalArgumentException("Not correct row");
        }

        int row = (int) (14 * rowPlacement);
        if (row == 14) {
            row = 13;
        }
        int size = passengers.length;

        int currentRow = row;
        int currentSide = 0; // 0 for left, 1 for right

        int i = 0;
        while (i < size) {
            boolean seatFound = false;
            while (!seatFound) {
                if (currentRow == 14){currentRow=13;}
                if (currentSide == 0) {
                    if (left[0][currentRow % 14].isAvailable() && left[1][currentRow % 14].isAvailable()) {
                        left[0][currentRow % 14].setPassenger(passengers[i]);
                        left[0][currentRow % 14].setTicket(new Ticket(left[0][currentRow % 14].getSeatNumber(), rowPlacement, passengers[i]));
                        left[0][currentRow % 14].getTicket().setPrice(120.0);
                        System.out.println(left[0][currentRow % 14].getTicket().toString());
                        i++;
                        if (i < size && left[1][currentRow % 14].isAvailable()) {
                            left[1][currentRow % 14].setPassenger(passengers[i]);
                            left[1][currentRow % 14].setTicket(new Ticket(left[1][currentRow % 14].getSeatNumber(), rowPlacement, passengers[i]));
                            left[1][currentRow % 14].getTicket().setPrice(130.0);
                            System.out.println(left[1][currentRow % 14].getTicket().toString());
                            i++;
                        }

                        seatFound = true;
                    }
                    currentSide = 1;
                } else {
                    if (right[0][currentRow % 14].isAvailable() && right[1][currentRow % 14].isAvailable()) {
                        right[0][currentRow % 14].setPassenger(passengers[i]);
                        right[0][currentRow % 14].setTicket(new Ticket(right[0][currentRow % 14].getSeatNumber(), rowPlacement, passengers[i]));
                        right[0][currentRow % 14].getTicket().setPrice(130.0);
                        System.out.println(right[0][currentRow % 14].getTicket().toString());

                        i++;
                        if (i < size && right[1][currentRow % 14].isAvailable()) {
                            right[1][currentRow % 14].setPassenger(passengers[i]);
                            right[1][currentRow % 14].setTicket(new Ticket(right[1][currentRow % 14].getSeatNumber(), rowPlacement, passengers[i]));
                            right[1][currentRow % 14].getTicket().setPrice(130.0);
                            System.out.println(right[1][currentRow % 14].getTicket().toString());
                            i++;
                        }

                        seatFound = true;
                    }
                    currentSide = 0;
                    currentRow++;
                }
            }
        }
    }
    @Override
    public void makeSeatFree(int seatNumber) {
        for (Seat[] value : this.right) {
            for (Seat seat : value) {
                if (seat != null && seat.getSeatNumber() == seatNumber) {
                    seat.setTicket(null);
                    return;
                }else if(seat == null){
                    throw  new NullPointerException("This seat is not sold. We cannot apply your request");
                }
            }
        }

        for (Seat[] seats : this.left) {
            for (Seat seat : seats) {
                if (seat != null && seat.getSeatNumber() == seatNumber) {
                    seat.setTicket(null);
                    return;
                }else if(seat == null){
                    throw  new NullPointerException("This seat is not sold. We cannot apply your request");
                }
            }
        }
        sold_seat--;
    }
    public int getSold_seat() {return sold_seat;}
    @Override
    public int getNumFreeSeats() {return NUM_SEATS-getSold_seat();}
}
