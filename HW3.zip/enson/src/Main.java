import BusTicketSystem.*;
import java.util.Scanner;

public class Main {
    public static Passenger getInfo(){ // to get info from user and make it object
        Scanner inp =new Scanner(System.in);
        String name,surname;
        char gender;
        int age;
        System.out.println("Name : ");name=inp.nextLine();
        System.out.println("Surname : ");surname= inp.nextLine();
        System.out.println("Age : ");age= inp.nextInt();
        System.out.println("Gender (press f for female, m for male): ");gender=inp.next().charAt(0);
        Passenger passenger = new Passenger(name,surname,age,gender);
        passenger.setGender(gender);
        return passenger;
    }

    public static void main(String[] args) {



        Scanner input =new Scanner(System.in);
        int bus_type ;
        System.out.println("WELCOME TO 114 E-TICKET SERVICE\n");
        System.out.println("Choose bus type as shown below (press 1 for above , 2 for below)");
        SingleSeat_bus singleSeatBus = new SingleSeat_bus(1,"CENG114");
        DoubleSeat_bus doubleSeatBus = new DoubleSeat_bus(2,"Ceng222");
        System.out.println(singleSeatBus.toString()); //show passengers to our bus type
        System.out.println("***********************************************************");
        System.out.println(doubleSeatBus.toString());
        System.out.println("**************************************************************");

        System.out.println("To buy a ticket press 1, to return your ticket press 2,to exit press -1");
        int choice = input.nextInt();

        while(choice!=-1){
            switch (choice){
                case 1 :  System.out.println("Which bus you want to travel ? ");
                    bus_type= input.nextInt();
                    System.out.println("How many ticket you want to buy ? ");
                    int ticket_number = input.nextInt();
                    System.out.println("Enter a row placement between 0.0 - 1.0");
                    double rowPlacement = input.nextDouble();

                    if(ticket_number == 1 && bus_type == 1){
                        Passenger passenger = getInfo();
                        singleSeatBus.sellSeat(passenger,rowPlacement);
                        System.out.println(singleSeatBus.toString());
                    } else if (ticket_number == 1 && bus_type == 2) {
                        Passenger passenger = getInfo();
                        doubleSeatBus.sellSeat(passenger,rowPlacement);
                        System.out.println(doubleSeatBus.toString());
                    } else if (ticket_number>1 && bus_type == 1){
                        Passenger[] pass = new Passenger[ticket_number];
                        for (int i = 0; i < ticket_number; i++) {
                            pass[i]=getInfo();
                        }
                        singleSeatBus.sellSeat(pass,rowPlacement);
                        System.out.println(singleSeatBus.toString());
                    } else if (ticket_number >1 && bus_type ==2) {
                        Passenger[] pass = new Passenger[ticket_number];
                        for (int i = 0; i < ticket_number; i++) {
                            pass[i] = getInfo();
                        }
                        doubleSeatBus.sellSeat(pass,rowPlacement);
                        System.out.println(doubleSeatBus.toString());
                    }

                break;

                case 2:
                    System.out.println("Which bus type did you buy ?");
                    int b= input.nextInt();
                    if(b == 1){
                        System.out.println("Enter the seat number : ");
                        int num = input.nextInt();
                        singleSeatBus.makeSeatFree(num);
                        System.out.println(singleSeatBus.toString());
                    } else if (b == 2) {
                        System.out.println("Enter the seat number : ");
                        int num = input.nextInt();
                        doubleSeatBus.makeSeatFree(num);
                        System.out.println(doubleSeatBus.toString());
                    }
                break;
            }

            System.out.println("To buy a ticket press 1, to return your ticket press 2,to exit press -1");
            choice = input.nextInt();
        }




    }
}